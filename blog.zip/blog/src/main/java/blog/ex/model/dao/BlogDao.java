package blog.ex.model.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import blog.ex.model.entity.BlogEntity;
import jakarta.transaction.Transactional;


public interface BlogDao extends JpaRepository<BlogEntity, Long> { 
	
	//accountIdにBlogEntityを取得
	List<BlogEntity> findByAccountId(Long AccountId);
	
	//DBに保存
	BlogEntity save(BlogEntity blogEntity);
	
	//titleとregisterDateを検査条件として、blogEntityを取得
	BlogEntity findByBlogTitleAndRegisterDate(String blogTitle,LocalDate registerDate);
	
	
	//findByBlogId methodを定義し、DBのBlogEntityを検索
	BlogEntity findByBlogId(Long blogId);
	
	
	//トランザクション管理は複数BD操作をまとめ、一括処理
	@Transactional
    List<BlogEntity> deleteByBlogId(Long blogId);
}
